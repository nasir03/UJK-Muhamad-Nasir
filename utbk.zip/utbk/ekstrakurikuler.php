<section id="ekstrakurikuler">
<h2>Ekstrakurikuler</h2>
        <p>
          Kami menawarkan berbagai kegiatan ekstrakurikuler untuk mengembangkan
          bakat dan minat siswa dan ada beberapa Ekstrakurikuler di antarnya:
        </p>
        <table>
          <tr>
            <th>Bulutangkis</th>
            <td>
              Ekstrakulikuler bulutangkis SMKN 4 Bandung lahir pada tahun 2016
              dengan tujuan menampung minat dan bakat siswa dan siswi SMK Negeri
              4 Bandung dalam bidang olahraga bulutangkis. Banyak sekali atlet-
              atlet bulutangkis yang terlahir di eskul bulutangkis SMK Negeri 4
              bandung yang mengharumkan nama sekolah bahkan mengharumkan nama
              Kota Bandung pada event kejuaraan bulutangkis tingkat jawa barat.
            </td>
          </tr>
          <tr>
            <th>Paskibra</th>
            <td>
              Paskibra SMKN 4 Bandung atau juga disebut dengan sebutan Blue
              Prince merupakan suatu ekstrakurikuler yang dapat menjadi media
              bagi anggotanya untuk membentuk nilai-nilai penting dalam dirinya.
              Dalam Ekstrakurikuler Paskibra dikenal dengan istilah Pandu Ibu
              Pertiwi yang Berpancasila yang merupakan landasan agar terciptanya
              para anggota yang memiliki sikap seorang Pandu yang setia dan
              patuh pada Negara Kesatuan Republik Indonesia.
            </td>
          </tr>
          <tr>
            <th>Pencak Silat</th>
            <td>
              "Ekstrakurikuler silat di sekolah kami menjadi tempat bagi para
              siswa untuk belajar seni bela diri tradisional yang kaya akan
              nilai-nilai budaya. Setiap gerakan silat yang diajarkan bukan
              hanya meningkatkan kebugaran fisik, tetapi juga menanamkan
              disiplin dan ketenangan batin. Dalam latihan bersama, kami
              merasakan kebersamaan dan saling mendukung untuk mencapai
              prestasi."
            </td>
          </tr>
          <tr>
            <th>Karate</th>
            <td>
              "Di sekolah kami, ekstrakurikuler karate menjadi favorit banyak
              siswa yang ingin mengasah kekuatan, ketahanan, dan konsentrasi.
              Dengan bimbingan pelatih yang berpengalaman, para siswa diajarkan
              teknik-teknik dasar hingga lanjutan. Lebih dari sekadar bela diri,
              karate mengajarkan kami tentang nilai-nilai kesabaran, keuletan,
              dan semangat pantang menyerah."
            </td>
          </tr>
          <tr>
            <th>Rohis</th>
            <td>
              Ekstrakurikuler Rohis di sekolah kami adalah tempat para siswa
              memperdalam pemahaman agama Islam dan menguatkan iman.
              Kegiatan-kegiatan seperti kajian rutin, diskusi keagamaan, dan
              aksi sosial menjadi sarana untuk mempererat ukhuwah Islamiyah di
              antara siswa. Di sini, kami belajar untuk menjadi pribadi yang
              berakhlak mulia dan bertanggung jawab, sesuai dengan ajaran
              Islam."
            </td>
          </tr>
        </table>
</section>
