<section id="beranda">
    <h2>Beranda</h2>
   <h1> <p align="center">
          MTS DARUL ARIFIN adalah tempat di mana impian dan aspirasi masa depan
          diwujudkan. Dengan komitmen pada keunggulan akademik dan pengembangan
          karakter, kami bangga menjadi lembaga pendidikan yang berperan aktif
          dalam membentuk generasi masa depan yang cerdas, berakhlak mulia, dan
          berdaya saing global.
        </p> </h1>
    <img src="poto_sekolah.jpg" alt="Foto Sekolah">
    <video controls>
        <source src="vidio_sekolah.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
</section>
