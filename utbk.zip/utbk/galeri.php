<section id="galeri">
        <h2>Galeri</h2>
        <p>Lihat berbagai foto dan kegitan kami di sekolah.</p>
        <div class="gambar-container">
          <img src="galeri/download.jpg" />
          <p class="teks">Upacara</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/OIP (1).jpg" />
          <p class="teks">Upacara Hari Kemerdekaan</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/OIP (2).jpg" />
          <p class="teks">Di Kelas</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/OIP (3).jpg" />
          <p class="teks">Anak OSIS</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/OIP.jpg" />
          <p class="teks">Praktek</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/karate.jpg" />
          <p class="teks">karate</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/silat.jpg" />
          <p class="teks">Silat</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/lebipa.jpg" />
          <p class="teks">Laboratarium</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/lebkom.jpg" />
          <p class="teks">Leb Komputer</p>
        </div>
        <div class="gambar-container">
          <img src="galeri/sholat.jpg" />
          <p class="teks">Sholat Berjamaah</p>
        </div>
      </section>